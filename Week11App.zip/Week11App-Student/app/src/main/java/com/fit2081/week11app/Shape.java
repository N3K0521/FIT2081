package com.fit2081.week11app;

public class Shape {
    public static final int CIRCLE = 1;
    public static final int RECTANGLE = 2;


    int type;
}
