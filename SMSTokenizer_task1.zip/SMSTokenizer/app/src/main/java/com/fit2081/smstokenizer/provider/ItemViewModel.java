package com.fit2081.smstokenizer.provider;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ItemViewModel extends AndroidViewModel {

    ItemRepository myRepository;
    LiveData<List<Item>> myAllItems;

    public ItemViewModel(@NonNull Application application) {
        super(application);
        myRepository = new ItemRepository(application);
        myAllItems = myRepository.getAllItems();
    }

    public LiveData<List<Item>> getAllItems() {
        return myAllItems;
    }

    public void insert(Item item) {
        myRepository.insert(item);
    }

    public void deleteAll(){
        myRepository.deleteAll();
    }
}

