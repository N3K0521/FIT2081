package com.fit2081.smstokenizer;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fit2081.smstokenizer.provider.Item;

import java.util.ArrayList;
import java.util.List;

public class MyRecyclerAdapter extends RecyclerView.Adapter<MyRecyclerAdapter.ViewHolder>{
    ArrayList<Item> data = new ArrayList<>();
    List<Item> myItems;

    public void setData(ArrayList<Item> _data) {
        this.data = _data;
    }

    public void setItems(List<Item> newData) {
        myItems=newData;
    }

    @NonNull
    @Override
    public MyRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Inflate a view and use it to create a view holder object, then return the view holder object.
        //View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false); //CardView inflated as RecyclerView list item
        //ViewHolder viewHolder = new ViewHolder(v);
        //Log.d("week6App","onCreateViewHolder");
        //return viewHolder;
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false);
        return new MyRecyclerAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerAdapter.ViewHolder holder, int position) {
        //Use position to set content of widgets inside the holder.

        //week 6:
        //holder.nameTv.setText(data.get(position).getName());
        //holder.quantityTv.setText(data.get(position).getQuantity());
        //holder.costTv.setText(data.get(position).getCost());
        //holder.descriptionTv.setText(data.get(position).getDescription());
        //holder.freezeTv.setText(String.valueOf(data.get(position).isFreeze()));
        //Log.d("week6App","onBindViewHolder");

        holder.nameTv.setText(myItems.get(position).getName());
        holder.quantityTv.setText(myItems.get(position).getQuantity());
        holder.costTv.setText(myItems.get(position).getCost());
        holder.descriptionTv.setText(myItems.get(position).getDescription());
        holder.freezeTv.setText(String.valueOf(myItems.get(position).isFreeze()));

    }

    @Override
    public int getItemCount() {
        if (myItems == null) {
            return 0;
        }else {
            return myItems.size();
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        //Provide access to view layout widgets
        View parentView;
        TextView nameTv;
        TextView quantityTv;
        TextView costTv;
        TextView descriptionTv;
        TextView freezeTv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            parentView = itemView;
            nameTv = itemView.findViewById(R.id.name_id);
            quantityTv = itemView.findViewById(R.id.quantity_id);
            costTv = itemView.findViewById(R.id.cost_id);
            descriptionTv = itemView.findViewById(R.id.description_id);
            freezeTv = itemView.findViewById(R.id.freeze_id);
        }
    }
}

