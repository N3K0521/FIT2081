package com.fit2081.smstokenizer.provider;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class ItemRepository {
    private ItemDao myItemDao;
    private LiveData<List<Item>> myAllItems;

    ItemRepository(Application application) {
        ItemDatabase db = ItemDatabase.getDatabase(application);
        myItemDao = db.itemDao();
        myAllItems = myItemDao.getAllItems();
    }

    LiveData<List<Item>> getAllItems() {
        return myAllItems;
    }

    void insert(Item item) {
        ItemDatabase.databaseWriteExecutor.execute(() -> myItemDao.addItem(item));
    }

    void deleteAll(){
        ItemDatabase.databaseWriteExecutor.execute(()->{
            myItemDao.deleteAllItems();
        });
    }
}

