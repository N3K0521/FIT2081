package com.fit2081.week11app;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener, GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener, ScaleGestureDetector.OnScaleGestureListener {
    CustomView view;
    private GestureDetectorCompat mDetector;
    private ScaleGestureDetector mScaleDetector;
    float gestrueDownX;
    float gestureDownY;
    int shape2Draw = Shape.CIRCLE;
//    int shape2Draw = Shape.RECTANGLE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        view = findViewById(R.id.myView);
        mDetector = new GestureDetectorCompat(this,this);
        mDetector.setOnDoubleTapListener(this);
        mScaleDetector = new ScaleGestureDetector(this, this);
        view.setOnTouchListener(this);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        if (shape2Draw == Shape.CIRCLE)
            view.addShape(new Circle((int) e.getX(), (int) e.getY(), 100));
        else
            view.addShape(new Rectangle((int) e.getX(), (int) e.getY(), (int) e.getX() +100, (int) e.getY() +100));
        return true;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        String shape;
        if(shape2Draw == Shape.CIRCLE){
            shape = "Rectangle";
            shape2Draw = Shape.RECTANGLE;
        }else{
            shape = "Circle";
            shape2Draw = Shape.CIRCLE;
        }
        Toast.makeText(this, shape, Toast.LENGTH_SHORT).show();
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }
    float scale = 1.0f;

    @Override
    public boolean onDown(MotionEvent e) {
        gestrueDownX = e.getX();
        gestureDownY = e.getY();
        return true;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return true;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
      if (shape2Draw == Shape.CIRCLE)
          view.addShape(new Circle((int) e2.getX(),(int) e2.getY(),100));
      else
          view.addShape(new Rectangle((int) e2.getX(),(int) e2.getY(), (int) e2.getX() +100, (int) e2.getY() +100));

        return true;
    }

    @Override
    public void onLongPress(MotionEvent e) {
        view.clearShapes();

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
       if (shape2Draw == Shape.CIRCLE)
           view.addShape(new Circle((int) e2.getX(), (int) e2.getY(), 100));
       else
           view.addShape(new Rectangle((int) e2.getX(), (int) e2.getY(), (int) e2.getX() +100, (int) e2.getY() +100));
        return true;
    }

    @Override
    public boolean onScale(ScaleGestureDetector detector) {
        scale *= detector.getScaleFactor();
        return true;
    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector detector) {
        return true;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector detector) {
        int scaleFactor = (int) (scale * 100);
        scale = 1.0f;
        if (shape2Draw == Shape.CIRCLE)
            view.addShape(new Circle((int) gestrueDownX, (int) gestureDownY, scaleFactor));
        else
            view.addShape(new Rectangle((int) gestrueDownX, (int) gestureDownY, (int) gestrueDownX + scaleFactor, (int) gestureDownY + scaleFactor));
    

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        this.mDetector.onTouchEvent(event);
        mScaleDetector.onTouchEvent(event);
        return true;
    }
}
