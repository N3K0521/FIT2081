package com.fit2081.smstokenizer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    ArrayList<Item> dataSource = new ArrayList<>();
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    MyRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        String dataStr = getIntent().getExtras().getString("DATA_KEY");
        Gson gson = new Gson();
        Type type = new TypeToken<ArrayList<Item>>() {}.getType();
        dataSource = gson.fromJson(dataStr,type);

        recyclerView = findViewById(R.id.my_recycler_view);
        layoutManager = new LinearLayoutManager(this);  //A RecyclerView.LayoutManager implementation which provides similar functionality to ListView.
        recyclerView.setLayoutManager(layoutManager);   // Also StaggeredGridLayoutManager and GridLayoutManager or a custom Layout manager

        adapter = new MainActivity2.MyRecyclerAdapter();
        adapter.setData(dataSource);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }

    public class MyRecyclerAdapter extends RecyclerView.Adapter<MyRecyclerAdapter.ViewHolder>{
        ArrayList<Item> data = new ArrayList<>();

        public void setData(ArrayList<Item> _data) {
            this.data = _data;
        }

        @NonNull
        @Override
        public MyRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            //Inflate a view and use it to create a view holder object, then return the view holder object.
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false); //CardView inflated as RecyclerView list item
            ViewHolder viewHolder = new ViewHolder(v);
            Log.d("week6App","onCreateViewHolder");
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull MyRecyclerAdapter.ViewHolder holder, int position) {
            //Use position to set content of widgets inside the holder.
            holder.nameTv.setText(data.get(position).getName());
            holder.quantityTv.setText(data.get(position).getQuantity());
            holder.costTv.setText(data.get(position).getCost());
            holder.descriptionTv.setText(data.get(position).getDescription());
            holder.freezeTv.setText(String.valueOf(data.get(position).isFreeze()));
            Log.d("week6App","onBindViewHolder");

        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder{
            View parentView;
            TextView nameTv;
            TextView quantityTv;
            TextView costTv;
            TextView descriptionTv;
            TextView freezeTv;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                parentView = itemView;
                nameTv = itemView.findViewById(R.id.name_id);
                quantityTv = itemView.findViewById(R.id.quantity_id);
                costTv = itemView.findViewById(R.id.cost_id);
                descriptionTv = itemView.findViewById(R.id.description_id);
                freezeTv = itemView.findViewById(R.id.freeze_id);
            }
        }
    }
}
