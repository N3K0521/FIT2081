package com.fit2081.smstokenizer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.StringTokenizer;


public class MainActivity extends AppCompatActivity {
    public static final String TAG = "WareHouse";
    private EditText itemText;
    private EditText quantitytext;
    private EditText costtext;
    private EditText descriptiontext;
    private ToggleButton togglebutton;
    private Button addButton;
    private Button clearButton;
    private DrawerLayout drawerlayout;
    private NavigationView navigationView;
    Toolbar toolbar;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawer_main_activity);
        Log.i(TAG, "onCreate");

        itemText=findViewById(R.id.item);
        quantitytext= findViewById(R.id.Quantity);
        costtext = findViewById(R.id.Cost);
        descriptiontext = findViewById(R.id.decription);
        togglebutton = findViewById(R.id.Frozen_Button);
        addButton = findViewById(R.id.Add_button);
        clearButton = findViewById(R.id.clear_button);
        drawerlayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);
       FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String itemName = itemText.getText().toString();
                Snackbar.make(view, "New item "+itemName+" has been added", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();




            }
        });

        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerlayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerlayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(new MyNavigationListener());



        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemName = itemText.getText().toString();
                String message=String.format("New item(%s) has been added",itemName);
                makeToast(message);

                ;}
        });

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                itemText.setText(" ");
                quantitytext.setText(" ");
                costtext.setText(" ");
                descriptiontext.setText(" ");
                togglebutton.setChecked(false);



            }
        });






        /* Request permissions to access SMS */
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 0);
        /* Create and instantiate the local broadcast receiver
           This class listens to messages come from class SMSReceiver
         */
        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();

        /*
         * Register the broadcast handler with the intent filter that is declared in
         * class SMSReceiver @line 11
         * */
        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER));



    }



    protected void onStart() {
        super.onStart();

        Log.i(TAG, "onStart");
    }

    protected void onResume() {
        super.onResume();
        restoreSharedPreferences();

        Log.i(TAG, "onResume");
    }

    protected void onPause() {
        super.onPause();
        saveSharedPreferences();
        Log.i(TAG, "onPause");

    }

    protected void onStop() {
        super.onStop();
        Log.i(TAG, "onStop");
    }

    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "onRestart");
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy");
    }



    protected void onSaveInstanceState(Bundle outState) {
        String itemName = itemText.getText().toString();
        outState.putString("itemName",itemName);
        String quantity = quantitytext.getText().toString();
        outState.putString("quantity",quantity);
        String cost = costtext.getText().toString();
        outState.putString("cost",cost);
        String description = descriptiontext.getText().toString();
        outState.putString("description",description);
        boolean frozenBt = togglebutton.isChecked();
        outState.putBoolean("frozenB",frozenBt);

        super.onSaveInstanceState(outState);



        Log.i(TAG, "onSaveInstanceState");


    }


    protected void onRestoreInstanceState(Bundle inState) {
        itemText.setText(inState.getString("itemName"));
        quantitytext.setText(inState.getString("quantity"));
        costtext.setText(inState.getString("cost"));
        descriptiontext.setText(inState.getString("description"));
        togglebutton.setChecked(inState.getBoolean("frozenB"));
        Log.i(TAG, "onRestoreInstanceState");

    }




    private void saveSharedPreferences(){
        SharedPreferences sharedPreferences = getSharedPreferences("mySP",MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        myEdit.putString("itemName",itemText.getText().toString());
        myEdit.putString("quantity",quantitytext.getText().toString());
        myEdit.putString("cost",costtext.getText().toString());
        myEdit.putString("description",descriptiontext.getText().toString());
        myEdit.putBoolean("frozenB",togglebutton.isChecked());

        myEdit.commit();
    }

    private void restoreSharedPreferences(){
        SharedPreferences sh = getSharedPreferences("mySP",MODE_PRIVATE);
        String s1 = sh.getString("itemName"," ");
        String s2 = sh.getString("quantity","0");
        String s3 = sh.getString("cost","0.0");
        String s4 = sh.getString("description"," ");
        boolean b1 = sh.getBoolean("frozenB",true);

        itemText.setText(s1);
        quantitytext.setText(s2);
        costtext.setText(s3);
        descriptiontext.setText(s4);
        togglebutton.setChecked(b1);




    }



    class MyBroadCastReceiver extends BroadcastReceiver {

        /*
         * This method 'onReceive' will get executed every time class SMSReceive sends a broadcast
         * */
        @Override
        public void onReceive(Context context, Intent intent) {
            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);
            /*
             * String Tokenizer is used to parse the incoming message
             * The protocol is to have the account holder name and account number separate by a semicolon
             * */

            StringTokenizer sT = new StringTokenizer(msg, ";");
            String item = sT.nextToken();
            String quantity = sT.nextToken();
            String cost = sT.nextToken();
            String description = sT.nextToken();
            String frozen_bt = sT.nextToken();


            itemText.setText(item);
            quantitytext.setText(quantity);
            costtext.setText(cost);
            descriptiontext.setText(description);
            togglebutton.setChecked(Boolean.parseBoolean(frozen_bt));
        }
    }

    class MyNavigationListener implements NavigationView.OnNavigationItemSelectedListener {




        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            // get the id of the selected item
            int id = item.getItemId();

            if (id == R.id.AddItem) {
                String itemName = itemText.getText().toString();
                String message=String.format("New item(%s) has been added",itemName);
                makeToast(message);
            } else if (id == R.id.ClearField) {

            }
            itemText.setText(" ");
            quantitytext.setText(" ");
            costtext.setText(" ");
            descriptiontext.setText(" ");
            togglebutton.setChecked(false);
            drawerlayout.closeDrawers();
            // tell the OS
            return true;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if (id == R.id.action_add) {
            String itemName = itemText.getText().toString();
            String message=String.format("New item(%s) has been added",itemName);
            makeToast(message);
        } else if (id == R.id.action_clear) {
            itemText.setText(" ");
            quantitytext.setText(" ");
            costtext.setText(" ");
            descriptiontext.setText(" ");
            togglebutton.setChecked(false);
        }
        return true;
    }






    private void makeToast(String s){
        Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
    };






}






























































