package com.fit2081.smstokenizer.provider;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "items")
public class Item {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "itemId")
    private int id;

    @ColumnInfo(name = "itemName")
    private String name;

    @ColumnInfo(name = "itemQuantity")
    private String quantity;

    @ColumnInfo(name = "itemCost")
    private String cost;

    @ColumnInfo(name = "itemDescription")
    private String description;

    @ColumnInfo(name = "itemFreeze")
    private boolean freeze;

    public Item(String name, String quantity, String cost, String description, boolean freeze) {
        this.name = name;
        this.quantity = quantity;
        this.cost = cost;
        this.description = description;
        this.freeze = freeze;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getCost() {
        return cost;
    }

    public String getDescription() {
        return description;
    }

    public boolean isFreeze() {
        return freeze;
    }

    public void setId(int id) {
        this.id = id;
    }
}

