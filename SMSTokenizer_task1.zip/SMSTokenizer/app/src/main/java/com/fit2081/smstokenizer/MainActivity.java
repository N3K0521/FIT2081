package com.fit2081.smstokenizer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.slice.SliceProvider;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.fit2081.smstokenizer.provider.Item;
import com.fit2081.smstokenizer.provider.ItemViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "LIFE_CYCLE_TRACING";

    private EditText nameText;
    private EditText quantityText;
    private EditText costText;
    private EditText descriptionText;
    private ToggleButton frozenBtn;

    private String name;
    private String quantity;
    private String cost;
    private String description;
    private boolean frozen;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    Toolbar toolbar;
    FloatingActionButton fab;

    ArrayList<Item> data = new ArrayList<>();

    ItemViewModel myItemViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "onCreate");
        //setContentView(R.layout.activity_main);
        setContentView(R.layout.drawer_main_activity);

        //Get the reference
        nameText = findViewById(R.id.editName);
        quantityText = findViewById(R.id.editQuantity);
        costText = findViewById(R.id.editCost);
        descriptionText = findViewById(R.id.editDescription);
        frozenBtn = findViewById(R.id.frozenBt);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);
        fab = findViewById(R.id.fab);

        //Request permissions to access SMS
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 0);

        //Create and instantiate the local broadcast receiver
        //This class listens to messages come from class SMSReceiver
        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();

        //Register the broadcast handler with the intent filter that is declared in class SMSReceiver
        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER));

        //Tool bar & Navigation view & FAB button
        //Set the toolbar to be the current toolbar for the activity
        setSupportActionBar(toolbar);
        //Hook the drawer and the toolbar using ActionBarDrawerToggle class
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(new MyNavigationListener());
        fab.setOnClickListener(new MyFabListener());

        myItemViewModel = new ViewModelProvider(this).get(ItemViewModel.class);

    }

    class MyBroadCastReceiver extends BroadcastReceiver {
        //This method 'onReceive' will get executed every time class SMSReceive sends a broadcast
        @Override
        public void onReceive(Context context, Intent intent) {
            //Retrieve the message from the intent
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);

            //String Tokenizer is used to parse the incoming message
            StringTokenizer sT = new StringTokenizer(msg, ";");  //separate by a semicolon
            String nameSMS = sT.nextToken();
            String quantitySMS = sT.nextToken();
            String costSMS = sT.nextToken();
            String descriptionSMS = sT.nextToken();
            String frozenSMS = sT.nextToken();

            //Update the UI
            nameText.setText(nameSMS);
            quantityText.setText(quantitySMS);
            costText.setText(costSMS);
            descriptionText.setText(descriptionSMS);
            if (frozenSMS.toLowerCase().equals("true")){
                frozenBtn.setChecked(true);
            }else if (frozenSMS.toLowerCase().equals("false")){
                frozenBtn.setChecked(false);
            }else{
                return;
            }

        }
    }

    class MyNavigationListener implements NavigationView.OnNavigationItemSelectedListener {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            // get the id of the selected item
            int id = item.getItemId();

            if (id == R.id.item_id_add) {
                onClickNew(null);
            } else if (id == R.id.item_id_clear) {
                onClickClear(null);
            } else if (id == R.id.item_id_list) {
                Context context = getApplicationContext();
                Intent intent = new Intent(context, ListView.class);
                //Gson gson = new Gson();
                //String dataStr = gson.toJson(data);
                //intent.putExtra("DATA_KEY", dataStr);
                startActivity(intent);
            }
            // close the drawer
            drawerLayout.closeDrawers();
            // tell the OS
            return true;
        }
    }

    class MyFabListener implements View.OnClickListener{
        @Override
        public void onClick(View v){
            Snackbar.make(v, "Item saved!", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
        }
    }

    //Options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if (id == R.id.item_id_add) {
            onClickNew(null);
        } else if (id == R.id.item_id_clear) {
            onClickClear(null);
        }
        return true;
    }

    protected void onStart() {
        super.onStart();
        Log.i(TAG, "onStart");
    }

    protected void onResume() {
        //restoreSharedPreferences();
        super.onResume();
        Log.i(TAG, "onResume");
    }

    protected void onPause() {
        super.onPause();
        //saveSharedPreferences();
        Log.i(TAG, "onPause");

    }

    protected void onStop() {
        super.onStop();
        Log.i(TAG, "onStop");
    }

    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "onRestart");
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy");
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //outState.putString("keyName", name);
        //outState.putString("keyQuantity", quantity);
        //outState.putString("keyCost", cost);
        //outState.putString("keyDescription", description);
        //outState.putBoolean("keyFrozen", frozen);
        Log.i(TAG, "onSaveInstanceState");

    }

    //only gets executed if inState != null so no need to check for null Bundle
    protected void onRestoreInstanceState(Bundle inState) {
        super.onRestoreInstanceState(inState);
        //name = inState.getString("keyName");
        //quantity = inState.getString("keyQuantity");
        //cost = inState.getString("keyCost");
        //description = inState.getString("keyDescription");
        //frozen = inState.getBoolean("keyFrozen");
        Log.i(TAG, "onRestoreInstanceState");
    }

    public void saveSharedPreferences(){
        //Get the data from edit text box
        name = nameText.getText().toString();
        quantity = quantityText.getText().toString();
        cost = costText.getText().toString();
        description = descriptionText.getText().toString();
        frozen = frozenBtn.isChecked();

        SharedPreferences sp = getSharedPreferences("save", 0);
        SharedPreferences.Editor editSP = sp.edit();

        //Save the data
        editSP.putString("nameKey", name);
        editSP.putString("quantityKey", quantity);
        editSP.putString("costKey", cost);
        editSP.putString("descriptionKey", description);
        editSP.putBoolean("frozenKey", frozen);
        editSP.apply();

        //Item item = new Item(name, quantity, cost, description, frozen);
        //data.add(item);
    }

    public void restoreSharedPreferences(){
        SharedPreferences sp = getSharedPreferences("save", 0);

        //Get the data saved before
        name = sp.getString("nameKey", "");
        quantity = sp.getString("quantityKey", "0");
        cost = sp.getString("costKey", "0.0");
        description = sp.getString("descriptionKey", "");
        frozen = sp.getBoolean("frozenKey", false);

        //Restore the data
        nameText.setText(name);

        if (quantity != ""){
            quantityText.setText(quantity);
        }else{
            quantityText.setText("0");
        }

        if (cost != ""){
            costText.setText(cost);
        }else{
            costText.setText("0.0");
        }

        descriptionText.setText(description);
        frozenBtn.setChecked(frozen);
    }

    public void onClickNew(View view){
        name = nameText.getText().toString();
        Toast toastNew = Toast.makeText(this,"New item (" + name + ") has been added.", Toast.LENGTH_LONG);
        toastNew.show();
        //week 6: saveSharedPreferences();

        quantity = quantityText.getText().toString();
        cost = costText.getText().toString();
        description = descriptionText.getText().toString();
        frozen = frozenBtn.isChecked();
        Item item = new Item(name, quantity, cost, description, frozen);
        myItemViewModel.insert(item);
    }

    public void onClickClear(View view){
        nameText.setText("");
        quantityText.setText("");
        costText.setText("");
        descriptionText.setText("");
        frozenBtn.setChecked(false);
        myItemViewModel.deleteAll();

        //Before week 7:
        //SharedPreferences sp = getSharedPreferences("save", 0);
        //SharedPreferences.Editor editSP = sp.edit();
        //editSP.putString("nameKey", "");
        //editSP.putString("quantityKey", "");
        //editSP.putString("costKey", "");
        //editSP.putString("descriptionKey", "");
        //editSP.putBoolean("frozenKey", false);
        //editSP.apply();
    }

}










