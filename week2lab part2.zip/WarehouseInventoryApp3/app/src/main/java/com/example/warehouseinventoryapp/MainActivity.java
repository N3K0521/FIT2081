package com.example.warehouseinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    EditText editText1;
    EditText editText2;
    EditText editText3;
    ToggleButton toggleButton;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editText = findViewById(R.id.editText3);
        editText1 = findViewById(R.id.editText4);
        editText2 = findViewById(R.id.editText5);
        editText3 = findViewById(R.id.editText6);
        toggleButton = findViewById(R.id.toggleButton);






    }

    public void onClickAddnewItem (View view){
        String editTextStr = editText.getText().toString();
        String editText1Str = editText.getText().toString();
        String editText2Str = editText.getText().toString();
        String editText3Str = editText.getText().toString();
        Toast toastAddnewItem = Toast.makeText(this,editTextStr + " has been added into New Item ", Toast.LENGTH_LONG);
        toastAddnewItem.show();


    }

    public void onClearAllItem (View view){
        editText.setText("");
        editText1.setText("");
        editText2.setText("");
        editText3.setText("");
        toggleButton.setChecked(isFinishing());

    }


}
