package edu.monash.fit2081.countryinfo;



import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;


public class WikiCountry extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wiki_country);
        final String selectedCountry = getIntent().getStringExtra("country");
        getSupportActionBar().setTitle("Wiki "+selectedCountry);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        WebView wikiWeb;
        wikiWeb=findViewById(R.id.Wiki_web);
        wikiWeb.setWebViewClient(new WebViewClient());
        wikiWeb.loadUrl("https://en.wikipedia.org/wiki/" + selectedCountry);

    }


    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                //NavUtils.navigateUpFromSameTask(this);
                finish();

                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
