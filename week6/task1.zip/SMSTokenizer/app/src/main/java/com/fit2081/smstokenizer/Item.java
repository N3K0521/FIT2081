package com.fit2081.smstokenizer;

public class Item {
    private String name;
    private String quantity;
    private String cost;
    private String description;
    private boolean freeze;

    public Item(String itemName, String itemQuantity, String itemCost, String itemDescription, boolean itemFreeze) {
        this.name = itemName;
        this.quantity = itemQuantity;
        this.cost = itemCost;
        this.description = itemDescription;
        this.freeze = itemFreeze;
    }

    public String getName() {
        return name;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getCost() {
        return cost;
    }

    public String getDescription() {
        return description;
    }

    public boolean isFreeze() {
        return freeze;
    }

}
