package com.fit2081.smstokenizer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;

import com.fit2081.smstokenizer.provider.Item;
import com.fit2081.smstokenizer.provider.ItemViewModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class ListView extends AppCompatActivity {
    ArrayList<Item> dataSource = new ArrayList<>();
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    MyRecyclerAdapter adapter;
    ItemViewModel myItemViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        //String dataStr = getIntent().getExtras().getString("DATA_KEY");
        //Gson gson = new Gson();
        //Type type = new TypeToken<ArrayList<Item>>() {
        //}.getType();
        //dataSource = gson.fromJson(dataStr, type);

        recyclerView = findViewById(R.id.my_recycler_view);
        layoutManager = new LinearLayoutManager(this);  //A RecyclerView.LayoutManager implementation which provides similar functionality to ListView.
        recyclerView.setLayoutManager(layoutManager);   // Also StaggeredGridLayoutManager and GridLayoutManager or a custom Layout manager

        adapter = new MyRecyclerAdapter();
        //adapter.setData(dataSource);
        recyclerView.setAdapter(adapter);

        myItemViewModel = new ViewModelProvider(this).get(ItemViewModel.class);
        myItemViewModel.getAllItems().observe(this, newData -> {
            adapter.setItems(newData);
            adapter.notifyDataSetChanged();
        });

    }
}



